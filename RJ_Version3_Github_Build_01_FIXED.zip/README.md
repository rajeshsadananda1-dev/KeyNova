# KeyNova V3

KeyNova Android V3 password generator.

## V3 calculation

For serial `ABCDE`, using the device's current local date:

- `Y` = current year
- `M` = current month (1–12)
- `D` = current day of month
- `W` = weekday where Sunday=7, Monday=1, ..., Saturday=6
- `N` = day of year (1–366)
- `S` = A+B+C+D+E
- `ACE` = digits 1,3,5
- `ECA` = ACE reversed

Then:

`V = 36873 XOR ((M×D) + Y + S³ + W² + N + (ACE×ECA))`

The displayed password is the lowest five decimal digits of `V`, zero-padded to five digits, then reversed.

Verified for 19-09-2026:

- 41805 → 03202
- 21212 → 62632
- 09899 → 74496
- 35894 → 73014
- 89486 → 53403

V4 remains blank for future use.
