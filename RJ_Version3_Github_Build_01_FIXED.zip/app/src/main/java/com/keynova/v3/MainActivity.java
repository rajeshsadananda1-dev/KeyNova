package com.keynova.v3;

import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "keynova";
    private static final String ACTIVATED = "activated";
    private static final String ACTIVATION_CODE = "RJ8050";

    private EditText serialInput;
    private TextView v3Result;
    private TextView dateText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        setContentView(R.layout.activity_main);

        if (!isActivated()) {
            showActivationDialog();
        }

        dateText = findViewById(R.id.dateText);
        serialInput = findViewById(R.id.serialInput);
        v3Result = findViewById(R.id.v3Result);
        Button generate = findViewById(R.id.generateButton);

        updateDateText();

        serialInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                v.postDelayed(() -> v.requestRectangleOnScreen(
                        new android.graphics.Rect(0, 0, v.getWidth(), v.getHeight()), true), 250);
            }
        });

        generate.setOnClickListener(v -> generateV3());
    }

    private boolean isActivated() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(ACTIVATED, false);
    }

    private void showActivationDialog() {
        final EditText input = new EditText(this);
        input.setHint("Activation code");
        input.setSingleLine(true);
        input.setInputType(1);

        new AlertDialog.Builder(this)
                .setTitle("Activate KeyNova")
                .setMessage("Enter the one-time activation code")
                .setView(input)
                .setCancelable(false)
                .setPositiveButton("Activate", (dialog, which) -> {
                    if (ACTIVATION_CODE.equals(input.getText().toString().trim())) {
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                .putBoolean(ACTIVATED, true).apply();
                        Toast.makeText(this, "Activated", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Invalid activation code", Toast.LENGTH_SHORT).show();
                        showActivationDialog();
                    }
                })
                .show();
    }

    private void updateDateText() {
        if (dateText != null) {
            dateText.setText("Date: " + new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        }
    }

    private void generateV3() {
        String serial = serialInput.getText().toString().trim();
        if (!serial.matches("\\d{5}")) {
            serialInput.setError("Enter exactly 5 digits");
            serialInput.requestFocus();
            return;
        }

        v3Result.setText(calculateVersion3(serial));
        updateDateText();
    }

    /**
     * Exact Version 3 calculation recovered from the original calNewest() logic.
     * Uses the device's current local date, Sunday=7, Monday=1 ... Saturday=6,
     * and day-of-year starting at 1.
     */
    private String calculateVersion3(String serial) {
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;
        int day = c.get(Calendar.DAY_OF_MONTH);

        int calendarWeekDay = c.get(Calendar.DAY_OF_WEEK);
        int weekDay = (calendarWeekDay == Calendar.SUNDAY) ? 7 : calendarWeekDay - 1;
        int dayOfYear = c.get(Calendar.DAY_OF_YEAR);

        int a = serial.charAt(0) - '0';
        int b = serial.charAt(1) - '0';
        int cc = serial.charAt(2) - '0';
        int d = serial.charAt(3) - '0';
        int e = serial.charAt(4) - '0';

        long digitSum = a + b + cc + d + e;
        long sumCube = digitSum * digitSum * digitSum;

        long ace = Long.parseLong("" + serial.charAt(0) + serial.charAt(2) + serial.charAt(4));
        long eca = Long.parseLong("" + serial.charAt(4) + serial.charAt(2) + serial.charAt(0));

        long intermediate =
                (long) month * day
                + year
                + sumCube
                + (long) weekDay * weekDay
                + dayOfYear
                + ace * eca;

        long value = 36873L ^ intermediate;

        String lastFive = String.format(Locale.US, "%05d", Math.floorMod(value, 100000L));
        return new StringBuilder(lastFive).reverse().toString();
    }
}
